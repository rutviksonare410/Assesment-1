 import React from 'react';
import CommissionForm from './components/CommissionForm';

function App() {
  return (
    <div>
      <h1>Commission Calculator</h1>
      <CommissionForm />
    </div>
  );
}

export default App;
