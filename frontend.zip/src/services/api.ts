export async function calculateCommission(data: {
  localSalesCount: number;
  foreignSalesCount: number;
  averageSaleAmount: number;
}) {
  const response = await fetch('https://localhost:5206/api/commission/calculate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  if (!response.ok) {
    throw new Error(await response.text());
  }

  return await response.json();
}