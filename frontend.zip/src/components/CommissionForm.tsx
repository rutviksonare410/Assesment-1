import React, { useState } from 'react';
import { calculateCommission } from '../services/api';

export default function CommissionForm() {
  const [form, setForm] = useState({ localSalesCount: 0, foreignSalesCount: 0, averageSaleAmount: 0 });
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState("");

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: Number(e.target.value) });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await calculateCommission(form);
      setResult(res);
      setError("");
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input name="localSalesCount" type="number" onChange={handleChange} placeholder="Local Sales Count" />
        <input name="foreignSalesCount" type="number" onChange={handleChange} placeholder="Foreign Sales Count" />
        <input name="averageSaleAmount" type="number" onChange={handleChange} placeholder="Average Sale Amount" />
        <button type="submit">Calculate</button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      {result && (
        <div>
          <h3>Avalpha Commission</h3>
          <p>Local: £{result.avalphaLocalCommission.toFixed(2)}</p>
          <p>Foreign: £{result.avalphaForeignCommission.toFixed(2)}</p>
          <p>Total: £{result.avalphaTotalCommission.toFixed(2)}</p>

          <h3>Competitor Commission</h3>
          <p>Local: £{result.competitorLocalCommission.toFixed(2)}</p>
          <p>Foreign: £{result.competitorForeignCommission.toFixed(2)}</p>
          <p>Total: £{result.competitorTotalCommission.toFixed(2)}</p>
        </div>
      )}
    </div>
  );
}
