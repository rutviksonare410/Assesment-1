using Microsoft.AspNetCore.Mvc;
using CommissionCalculatorAPI.Models;

namespace CommissionCalculatorAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CommissionController : ControllerBase
    {
        [HttpPost]
        public ActionResult<CommissionResponseDto> CalculateCommission([FromBody] CommissionRequestDto request)
        {
            if (request.LocalSalesCount < 0 || request.ForeignSalesCount < 0 || request.AverageSaleAmount < 0 || request.AverageSaleAmount > 100000)
            {
                return BadRequest("Invalid input values.");
            }

            var avalphaLocal = 0.20m * request.LocalSalesCount * request.AverageSaleAmount;
            var avalphaForeign = 0.35m * request.ForeignSalesCount * request.AverageSaleAmount;

            var competitorLocal = 0.02m * request.LocalSalesCount * request.AverageSaleAmount;
            var competitorForeign = 0.0755m * request.ForeignSalesCount * request.AverageSaleAmount;

            var response = new CommissionResponseDto
            {
                AvalphaLocalCommission = avalphaLocal,
                AvalphaForeignCommission = avalphaForeign,
                AvalphaTotalCommission = avalphaLocal + avalphaForeign,
                CompetitorLocalCommission = competitorLocal,
                CompetitorForeignCommission = competitorForeign,
                CompetitorTotalCommission = competitorLocal + competitorForeign
            };

            return Ok(response);
        }
    }
}
