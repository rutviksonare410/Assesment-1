namespace CommissionCalculatorAPI.Models
{
    public class CommissionRequestDto
    {
        public int LocalSalesCount { get; set; }
        public int ForeignSalesCount { get; set; }
        public decimal AverageSaleAmount { get; set; }
    }
}
