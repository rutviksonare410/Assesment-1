namespace CommissionCalculatorAPI.Models
{
    public class CommissionResponseDto
    {
        public decimal AvalphaLocalCommission { get; set; }
        public decimal AvalphaForeignCommission { get; set; }
        public decimal AvalphaTotalCommission { get; set; }

        public decimal CompetitorLocalCommission { get; set; }
        public decimal CompetitorForeignCommission { get; set; }
        public decimal CompetitorTotalCommission { get; set; }
    }
}
